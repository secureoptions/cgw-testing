import boto3
from botocore.exceptions import ClientError
from ec2_metadata import ec2_metadata
import xml.etree.ElementTree as ET
import re

# Get local public ipv4 to create CGW
localPublicIp = ec2_metadata.public_ipv4

class Cgw:
    def __init__(self, asn, region_name=ec2_metadata.region):
        ec2 = boto3.client('ec2', region_name)
        response = ec2.create_customer_gateway(
            BgpAsn=asn,
            PublicIp=localPublicIp,
            Type='ipsec.1'
        )
        response = response['CustomerGateway']
        self.id = response['CustomerGatewayId']
        self.asn = response['BgpAsn']
        self.ip = response['IpAddress']
        self.state = response['State']

class Vpn:
    def __init__(self, cgw, gw, staticRouting, region_name=ec2_metadata.region):
        m = re.match(r'tgw-.*', gw)
        args = {}
        ec2 = boto3.client('ec2', region_name)
        if m:
            response = ec2.create_vpn_connection(
                    CustomerGatewayId=cgw,
                    TransitGatewayId=gw,
                    Type='ipsec.1',
                    Options={
                        'StaticRoutesOnly': staticRouting
                    }
            )
        else:
            response = ec2.create_vpn_connection(
                    CustomerGatewayId=cgw,
                    VpnGatewayId=gw,
                    Type='ipsec.1',
                    Options={
                        'StaticRoutesOnly': staticRouting
                    }
            )
        # Get new VPN metadata 
        download_config = response['VpnConnection']['CustomerGatewayConfiguration']
        root = ET.fromstring(download_config)
        self.name = response['VpnConnection']['VpnConnectionId']
        if staticRouting == False:
            # TUNNEL 1 INFO
            self.cgw_outside = ec2_metadata.public_ipv4
            self.local_inside1 = root[3][0][1][0].text
            self.remote_outside1 = root[3][1][0][0].text
            self.remote_inside1 = root[3][1][1][0].text
            self.psk1 = root[3][2][5].text

            # TUNNEL 2 INFO
            self.local_inside2 = root[4][0][1][0].text
            self.remote_outside2 = root[4][1][0][0].text
            self.remote_inside2 = root[4][1][1][0].text
            self.psk2 = root[4][2][5].text
            self.remote_asn = '64512'
        else:
            # TUNNEL 1 INFO
            self.cgw_outside = ec2_metadata.public_ipv4.encode('utf-8')
            self.local_inside1 = root[4][0][1][0].text
            self.remote_outside1 = root[4][1][0][0].text
            self.remote_inside1 = root[4][1][1][0].text
            self.psk1 = root[4][2][5].text
            
            # TUNNEL 2 INFO
            self.local_inside2 = root[5][0][1][0].text
            self.remote_outside2 = root[5][1][0][0].text
            self.remote_inside2 = root[5][1][1][0].text
            self.psk2 = root[5][2][5].text
            self.remote_asn = '64512'

def del_vpn(vpn, region_name='us-east-1'):
    ec2 = boto3.client('ec2', region_name)
    try:
        ec2.delete_vpn_connection(
            VpnConnectionId=vpn
        )
    except:
        pass