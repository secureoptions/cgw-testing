import boto3
from botocore.exceptions import ClientError
from ec2_metadata import ec2_metadata
import xml.etree.ElementTree as ET
import re
import sqlite3
import time


# Get local public ipv4 to create CGW
localPublicIp = ec2_metadata.public_ipv4

class Cgw:
    def __init__(self, asn, region_name=ec2_metadata.region):
        ec2 = boto3.client('ec2', region_name)
        response = ec2.create_customer_gateway(
            BgpAsn=asn,
            PublicIp=localPublicIp,
            Type='ipsec.1'
        )
        response = response['CustomerGateway']
        self.id = response['CustomerGatewayId']
        self.asn = response['BgpAsn']
        self.ip = response['IpAddress']
        self.state = response['State']

class Vpn:
    def __init__(self, cgw, gw, staticRouting, region_name=ec2_metadata.region):
        # initiate sqlite3
        conn = sqlite3.connect('/etc/strongswan/cgw-db.sqlite3')
        c = conn.cursor()
        # See if GW id exists in DB. If it does, skip configuration
        c.execute('''SELECT vpn, gateway FROM resources WHERE gateway=?''', (gw,))
        exists = c.fetchall()

        m = re.match(r'tgw-.*', gw)
        args = {}
        ec2 = boto3.client('ec2', region_name)
        if m and not exists :
            response = ec2.create_vpn_connection(
                    CustomerGatewayId=cgw,
                    TransitGatewayId=gw,
                    Type='ipsec.1',
                    Options={
                        'StaticRoutesOnly': staticRouting
                    }
            )
            response = response['VpnConnection']
        elif not exists:
            response = ec2.create_vpn_connection(
                    CustomerGatewayId=cgw,
                    VpnGatewayId=gw,
                    Type='ipsec.1',
                    Options={
                        'StaticRoutesOnly': staticRouting
                    }
            )
            response = response['VpnConnection']
        else:
            response = ec2.describe_vpn_connections(
                VpnConnectionIds=[
                    exists[0][0],
                ]
            )
            response = response['VpnConnections'][0]

        # Get new VPN metadata 
        download_config = response['CustomerGatewayConfiguration']
        root = ET.fromstring(download_config)
        self.name = response['VpnConnectionId']
        if staticRouting == False:
            # TUNNEL 1 INFO
            self.cgw_outside = ec2_metadata.public_ipv4
            self.local_inside1 = root[3][0][1][0].text
            self.remote_outside1 = root[3][1][0][0].text
            self.remote_inside1 = root[3][1][1][0].text
            self.psk1 = root[3][2][5].text

            # TUNNEL 2 INFO
            self.local_inside2 = root[4][0][1][0].text
            self.remote_outside2 = root[4][1][0][0].text
            self.remote_inside2 = root[4][1][1][0].text
            self.psk2 = root[4][2][5].text
            self.remote_asn = '64512'
        else:
            # TUNNEL 1 INFO
            self.cgw_outside = ec2_metadata.public_ipv4.encode('utf-8')
            self.local_inside1 = root[4][0][1][0].text
            self.remote_outside1 = root[4][1][0][0].text
            self.remote_inside1 = root[4][1][1][0].text
            self.psk1 = root[4][2][5].text
            
            # TUNNEL 2 INFO
            self.local_inside2 = root[5][0][1][0].text
            self.remote_outside2 = root[5][1][0][0].text
            self.remote_inside2 = root[5][1][1][0].text
            self.psk2 = root[5][2][5].text
            self.remote_asn = '64512'
        
        if not exists:
            # Add the connection metadata to db
            c.execute('INSERT INTO resources VALUES(?,?,?,?)', (cgw, self.name, gw, region_name))
            conn.commit()
            conn.close()

def del_vpn(vpn, region_name='us-east-1'):
    ec2 = boto3.client('ec2', region_name)
    try:
        ec2.delete_vpn_connection(
            VpnConnectionId=vpn
        )
        while True:
            # wait for vpn to delete before attempting to delete CGW
            response = ec2.describe_vpn_connections(
                VpnConnectionIds=[
                    vpn
                ]
            )
            if response['VpnConnections'][0]['State'] == 'deleted':
                break
            else:
                time.sleep(5)
        
        # Now attempt to delete CGW. If doesn't delete assume that there are other VPNs using it
        ec2.delete_customer_gateway(
            CustomerGatewayId=response['VpnConnections'][0]['CustomerGatewayId']
        )
    except:
        pass